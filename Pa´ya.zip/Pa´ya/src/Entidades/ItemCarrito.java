/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Juandis
 */
public class ItemCarrito {
    public int productoId;
    public String nombre;
    public double precio;
    public int cantidad;
   
    public ItemCarrito(int productoId, String nombre, double precio, int cantidad) {
        this.productoId = productoId;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

   

    public double getSubtotal() {
        return this.precio * this.cantidad;
    }

}
