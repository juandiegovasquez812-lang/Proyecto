/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author prestamo
 */
public class Facturas {
    private int id;
    private int pedido_id;
    private int metodo_pago_id;
    private Float monto_total;
    private String fecha_emision;

    public Facturas(int id, int pedido_id, int metodo_pago_id, Float monto_total, String fecha_emision) {
        this.id = id;
        this.pedido_id = pedido_id;
        this.metodo_pago_id = metodo_pago_id;
        this.monto_total = monto_total;
        this.fecha_emision = fecha_emision;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPedido_id() {
        return pedido_id;
    }

    public void setPedido_id(int pedido_id) {
        this.pedido_id = pedido_id;
    }

    public int getMetodo_pago_id() {
        return metodo_pago_id;
    }

    public void setMetodo_pago_id(int metodo_pago_id) {
        this.metodo_pago_id = metodo_pago_id;
    }

    public Float getMonto_total() {
        return monto_total;
    }

    public void setMonto_total(Float monto_total) {
        this.monto_total = monto_total;
    }

    public String getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(String fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    @Override
    public String toString() {
        return "Facturas{" + "id=" + id + ", pedido_id=" + pedido_id + ", metodo_pago_id=" + metodo_pago_id + ", monto_total=" + monto_total + ", fecha_emision=" + fecha_emision + '}';
    }
}
