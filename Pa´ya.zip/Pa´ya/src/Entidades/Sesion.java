/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author prestamo
 */
public class Sesion {
   public static int usuarioId = 0;
    public static String nombre = "";
    public static String email = "";

    // Método opcional para limpiar los datos cuando el usuario cierre sesión
    public static void cerrarSesion() {
        usuarioId = 0;
        nombre = "";
        email = "";
    }
}