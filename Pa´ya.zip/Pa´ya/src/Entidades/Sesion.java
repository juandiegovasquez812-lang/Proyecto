/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

public class Sesion {
    // Datos del usuario logueado
    public static int usuarioId = 0;
    public static String nombre = "";
    public static String email = "";

    // Datos del negocio seleccionado actualmente por el usuario
    public static int comercioIdActivo = 0;
    public static String nombreComercioActivo = "";

    public static void cerrarSesion() {
        usuarioId = 0;
        nombre = "";
        email = "";
        comercioIdActivo = 0;
        nombreComercioActivo = "";
    }
}
