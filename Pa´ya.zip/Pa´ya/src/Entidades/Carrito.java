/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Juandis
 */
public class Carrito {
     public static int comercioIdActual = 0;
    public static String nombreComercioActual = "";
    public static List<ItemCarrito> items = new ArrayList<>();

    public static void agregarProducto(int comercioId, String nombreComercio, int productoId, String nombreProd, double precio, int cantidad) {
        // Si el cliente cambia de restaurante, limpia el carrito para no mezclar pedidos de distintos locales
        if (comercioIdActual != 0 && comercioIdActual != comercioId) {
            items.clear();
        }
        comercioIdActual = comercioId;
        nombreComercioActual = nombreComercio;

        for (ItemCarrito item : items) {
            if (item.productoId == productoId) {
                item.cantidad += cantidad;
                return;
            }
        }
        items.add(new ItemCarrito(productoId, nombreProd, precio, cantidad));
    }

    public static double calcularSubtotal() {
        double total = 0;
        for (ItemCarrito item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    public static void vaciarCarrito() {
        comercioIdActual = 0;
        nombreComercioActual = "";
        items.clear();
    }
}

