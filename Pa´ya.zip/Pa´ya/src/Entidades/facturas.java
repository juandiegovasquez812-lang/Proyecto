/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author prestamo
 */
public class facturas {
    private int facturas_id;
    private String codigo_pedido;
     private String fecha_emision;
     private int usuario_id;
     private int comercio_id;
     private int repartidor_id;
     private int direccion_id;
     private int metodo_pago_id;
     private String subtotal_productos;
     private String costo_envio;
     private String propina_repartidor;
     private String total_pagado;
     private String estado_pago;

    public facturas(int facturas_id, String codigo_pedido, String fecha_emision, int usuario_id, int comercio_id, int repartidor_id, int direccion_id, int metodo_pago_id, String subtotal_productos, String costo_envio, String propina_repartidor, String total_pagado, String estado_pago) {
        this.facturas_id = facturas_id;
        this.codigo_pedido = codigo_pedido;
        this.fecha_emision = fecha_emision;
        this.usuario_id = usuario_id;
        this.comercio_id = comercio_id;
        this.repartidor_id = repartidor_id;
        this.direccion_id = direccion_id;
        this.metodo_pago_id = metodo_pago_id;
        this.subtotal_productos = subtotal_productos;
        this.costo_envio = costo_envio;
        this.propina_repartidor = propina_repartidor;
        this.total_pagado = total_pagado;
        this.estado_pago = estado_pago;
    }

    public int getFacturas_id() {
        return facturas_id;
    }

    public void setFacturas_id(int facturas_id) {
        this.facturas_id = facturas_id;
    }

    public String getCodigo_pedido() {
        return codigo_pedido;
    }

    public void setCodigo_pedido(String codigo_pedido) {
        this.codigo_pedido = codigo_pedido;
    }

    public String getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(String fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }

    public int getComercio_id() {
        return comercio_id;
    }

    public void setComercio_id(int comercio_id) {
        this.comercio_id = comercio_id;
    }

    public int getRepartidor_id() {
        return repartidor_id;
    }

    public void setRepartidor_id(int repartidor_id) {
        this.repartidor_id = repartidor_id;
    }

    public int getDireccion_id() {
        return direccion_id;
    }

    public void setDireccion_id(int direccion_id) {
        this.direccion_id = direccion_id;
    }

    public int getMetodo_pago_id() {
        return metodo_pago_id;
    }

    public void setMetodo_pago_id(int metodo_pago_id) {
        this.metodo_pago_id = metodo_pago_id;
    }

    public String getSubtotal_productos() {
        return subtotal_productos;
    }

    public void setSubtotal_productos(String subtotal_productos) {
        this.subtotal_productos = subtotal_productos;
    }

    public String getCosto_envio() {
        return costo_envio;
    }

    public void setCosto_envio(String costo_envio) {
        this.costo_envio = costo_envio;
    }

    public String getPropina_repartidor() {
        return propina_repartidor;
    }

    public void setPropina_repartidor(String propina_repartidor) {
        this.propina_repartidor = propina_repartidor;
    }

    public String getTotal_pagado() {
        return total_pagado;
    }

    public void setTotal_pagado(String total_pagado) {
        this.total_pagado = total_pagado;
    }

    public String getEstado_pago() {
        return estado_pago;
    }

    public void setEstado_pago(String estado_pago) {
        this.estado_pago = estado_pago;
    }

    @Override
    public String toString() {
        return "facturas{" + "facturas_id=" + facturas_id + ", codigo_pedido=" + codigo_pedido + ", fecha_emision=" + fecha_emision + ", usuario_id=" + usuario_id + ", comercio_id=" + comercio_id + ", repartidor_id=" + repartidor_id + ", direccion_id=" + direccion_id + ", metodo_pago_id=" + metodo_pago_id + ", subtotal_productos=" + subtotal_productos + ", costo_envio=" + costo_envio + ", propina_repartidor=" + propina_repartidor + ", total_pagado=" + total_pagado + ", estado_pago=" + estado_pago + '}';
    }
}
